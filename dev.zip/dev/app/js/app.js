var DukeApp = new Marionette.Application();

DukeApp.addRegions({
	content:"#content",
	modal:"#modal"
});

DukeApp.navigate = function(route, options){
	options = options || (options = {});
	Backbone.history.navigate(route, options);
};

DukeApp.getCurrentRoute = function() {
	return Backbone.history.fragment;
};

//globals
DukeApp.currentViewName = "";
DukeApp.currentView = undefined;

//initializer
DukeApp.on("initialize:after", function() {
	Parse.initialize("0GUnrQeUHPGhfJNLDzssuTUqUbJtvk1bib3mbas0", "zV8yxUl1QUs1efsUbhOU2LLiwTIN2bWfTK7GlxPN");

	if (!DukeApp.utils.isLoggedIn) {
		DukeApp.utils.initUserSettings();
	}
	
	if(Backbone.history){
		Backbone.history.start();

		DukeApp.utils.loadCommonViews();

		if (this.getCurrentRoute() === "") {
			DukeApp.trigger("home:login");
		}
	}
});