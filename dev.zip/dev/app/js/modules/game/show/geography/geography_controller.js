DukeApp.module("Game.Show.Geography", function(Geography, DukeApp, Backbone, Marionette, $, _) {
	Geography.Controller = {
		init:function(){
			console.log(Geography.Controller.loadResources);
		},

		loadResourses:function() {
			var baseDir =  "../images/game",
				queue = new createjs.LoadQueue(),
				queueValues = [
						{id:"map", src:baseDir + "/geography/map.png"},
						{id:"university", src:baseDir + "/geography/university_icon.png"},
						{id:"side_menu", src:baseDir + "/geography/side_menu.png"},
						{id:"dot", src:baseDir + "/geography/dot.png"},
						{id:"dot_selected", src:baseDir + "/geography/selected_dot.png"},
						{id:"button", src:baseDir + "/geography/button.png"},
						{id:"button_selected", src:baseDir + "/geography/selected_button.png"},
						{id:"rollover_menu", src:baseDir + "/geography/rollover_menu.png"},
						{id:"avatar", src:"../images/avatars/avatar.png"}
				];

			Show.Controller.currentGame = gameId;
			Show.Controller.gameResources = queue;

			queue.loadManifest(queueValues);
			queue.addEventListener("complete", this.loadGame);
		},

		loadGame:function(e) {
			var stage = new createjs.Stage("game_container"),
				resources = Show.Controller.gameResources;
			Show.Controller.canvas = stage;
			
			var background = new createjs.Bitmap(resources.getResult("map")),
				side_menu = new createjs.Bitmap(resources.getResult("side_menu")),
				avatar = new createjs.Bitmap(resources.getResult("avatar")),
				sidebarText = [
					{type:"climate",	label:new createjs.Text("Desired Climate:", "bold 15px Helvetica", "#000000"), 		text:new createjs.Text("Warm", "14px Helvetica", "#000000")},
					{type:"major",		label:new createjs.Text("Desired Major:", "bold 15px Helvetica", "#000000"), 				text:new createjs.Text("Computer Science", "14px Helvetica", "#000000")},
					{type:"cost",		label:new createjs.Text("Desired Cost:", "bold 15px Helvetica", "#000000"), 				text:new createjs.Text("40,000 per year", "14px Helvetica", "#000000")},
					{type:"extraCur",	label:new createjs.Text("Desired Extracurriculars:", "bold 15px Helvetica", "#000000"), 	text:new createjs.Text("Sports, Drama, Greek", "14px Helvetica", "#000000")},
					{type:"size",		label:new createjs.Text("Desired Size:", "bold 15px Helvetica", "#000000"), 				text:new createjs.Text("6,000 students", "14px Helvetica", "#000000")},
					{type:"athletics",	label:new createjs.Text("Desired Athletic Programs:", "bold 15px Helvetica", "#000000"), 	text:new createjs.Text("Football, Basketball", "14px Helvetica", "#000000")},
					{type:"rep",		label:new createjs.Text("Desired Reputations:", "bold 15px Helvetica", "#000000"), 		text:new createjs.Text("Ivy League", "14px Helvetica", "#000000")},
					{type:"job",		label:new createjs.Text("Desired Job Placement:", "bold 15px Helvetica", "#000000"), 	text:new createjs.Text("100% success rate", "14px Helvetica", "#000000")},
					{type:"grad",		label:new createjs.Text("Desired Graduate School:", "bold 15px Helvetica", "#000000"), 	text:new createjs.Text("Yes", "14px Helvetica", "#000000")}
				],

				button = new createjs.Bitmap(resources.getResult("button")),
				button_text_1 = new createjs.Text("SELECT", "15px Arial", "#ffffff"),
				button_text_2 = new createjs.Text("School Name", "22px Arial", "#000000"),
				
				selectionButton = new createjs.Container(),
				sidebar = new createjs.Container();

			selectionButton.addChild(button);
			selectionButton.addChild(button_text_1);
			selectionButton.addChild(button_text_2);

			button.x = 0;
			button.y = 0;

			button_text_1.x = button.getBounds().width/2 - button_text_1.getBounds().width/2;
			button_text_1.y = 10;

			button_text_2.x = button.getBounds().width/2 - button_text_2.getBounds().width/2;
			button_text_2.y = 30;
			
			selectionButton.x = 690;
			selectionButton.y = 490;

			//sidebar
			sidebar.addChild(side_menu);
			sidebar.addChild(avatar);

			avatar.x = 30;
			avatar.y = 5;
			avatar.scaleX = 0.8;
			avatar.scaleY = 0.8;

			side_menu.x = 0;
			side_menu.y = 0;

			var textStartX = 210,
				textStartY = 223;

			_.each(sidebarText, function(obj, idx){
				obj.label.x = obj.text.x = textStartX;

				obj.label.y = textStartY;
				obj.text.y = textStartY + 13;

				obj.label.textAlign = obj.text.textAlign = "right";

				textStartY += 39 - idx*0.3;

				sidebar.addChild(obj.label);
				sidebar.addChild(obj.text);
			});

			//add to stage
			stage.addChild(background);
			stage.addChild(sidebar);			
			stage.addChild(selectionButton);

			stage.update();

			this.restart();
		},

		restart:function() {
			
			var square = new createjs.Shape();
			square.graphics.beginFill("red").drawRect(0,0, 200, 200);

			stage.addChild(square);
			stage.update();
		}
	}
});