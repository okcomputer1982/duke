DukeApp.module("Components.Header", function(Header, DukeApp, Backbone, Marionette, $, _) {

  Header.HeaderView = Marionette.ItemView.extend({
    template: templates['_components/header/header'],

    onShow:function() {
        $('.header_link').click(this.handleHeaderLink);
        var adminType = DukeApp.utils.getCurrentAdminType();

        //check for current admin setting
        if (adminType === DukeApp.utils.AdminTypes.student || adminType === DukeApp.utils.AdminTypes.guest) {
            $("#admin_link").hide();
        }

    },

    handleHeaderLink:function(e){
        e.preventDefault();
        var type = $(e.currentTarget).attr('id');

        var links = {
            "coursework_link":"weekExplorer:week",
            "dashboard_link":"profile:student",
            "logout_link":"home:login",
        };

        // $("a.active").removeClass("active");
        // $(e.currentTarget).addClass("active");

        if (type === "coursework_link")
            DukeApp.trigger(links[type], 1, true);
        else
            DukeApp.trigger(links[type]);
    }
  });
});